Original Authors
----------------

 * Mitchell Wills (mwills@wpi.edu)

Contributors
------------

 * [Russell Toris](https://github.com/rctoris/) (russell.toris@gmail.com)
